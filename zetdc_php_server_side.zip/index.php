<?php
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        include("account/includes/connection.php");
        $email=mysqli_real_escape_string($conn,$_POST['email']);
        $password=mysqli_real_escape_string($conn,$_POST['password']);
        $execute=mysqli_query($conn,"SELECT  * FROM tblusers WHERE fldemail='$email' and fldpassword=MD5('$password') LIMIT 0,1") or die(mysqli_error($conn));
        if(mysqli_num_rows($execute)==1){
            @session_start();
            $credentials=mysqli_fetch_assoc($execute);
            $_SESSION["email"]=$email;
            $_SESSION["accesslevel"]=$credentials["fldaccesslevel"];
            header("Location: account/index.php");
        }else{
            $error=True;
        }
    }else{
      @session_start();
      if(isset($_SESSION["email"]) && isset($_SESSION["accesslevel"])){
        header("Location: account/index.php");
      }
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>ZETDC</title>

    <!-- Bootstrap Core CSS -->
    <link href="styles/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="styles/css/style.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="styles/fonts/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="styles/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body style="background: url(styles/img/bg.jpg) no-repeat center fixed;background-size: cover;">

<div class="container">
  
  <div class="row" id="pwd-container">
    <div class="col-md-4"></div>
    
    <div class="col-md-4">
      <section class="login-form">
        <form method="post" action="#" role="login">
          <img src="styles/img/logo.png" class="img-fluid" alt="" />
          <h2 align='center'>D.P.G.S.</h2>
          <input type="email" name="email" placeholder="Email" required class="form-control input-lg" <?php if(isset($email)){ echo " value='$email'"; } ?> />
          
          <input type="password" <?php if(isset($error)){ echo "autofocus"; } ?> class="form-control input-lg <?php if(isset($error)){ echo 'is-invalid'; } ?>" name="password" id="inputPassword" placeholder="Password" required/>        
          <button type="submit" name="go" class="btn btn-lg btn-primary btn-block">Sign in</button>
         
        </form>
      </section>  
      </div>
      
      <div class="col-md-4"></div>  
  </div>  
</div>

    <!-- jQuery -->
    <script src="account/vendor/jquery/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="styles/js/bootstrap.min.js"></script>
</body>

</html>
