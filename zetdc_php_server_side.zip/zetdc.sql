-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 02, 2019 at 02:09 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zetdc`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblassets`
--

CREATE TABLE `tblassets` (
  `fldchasisno` varchar(50) NOT NULL,
  `fldtype` varchar(50) DEFAULT NULL,
  `fldstatus` varchar(20) NOT NULL,
  `fldinstallationdate` varchar(10) DEFAULT NULL,
  `fldspecifications` varchar(200) DEFAULT NULL,
  `fldservicing_routine_period` int(11) NOT NULL,
  `flddecommissioned_date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblassets`
--

INSERT INTO `tblassets` (`fldchasisno`, `fldtype`, `fldstatus`, `fldinstallationdate`, `fldspecifications`, `fldservicing_routine_period`, `flddecommissioned_date`) VALUES
('23243G', 'Transformer', 'Operational', '', '5MW', 100, ''),
('325345345345', 'Transformer', 'Operational', '', '43KV Stepup', 1000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tblconnections`
--

CREATE TABLE `tblconnections` (
  `fldnode1` int(11) NOT NULL,
  `fldnode2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblconnections`
--

INSERT INTO `tblconnections` (`fldnode1`, `fldnode2`) VALUES
(188, 189),
(188, 352),
(189, 190),
(190, 191),
(191, 192),
(192, 193),
(192, 200),
(193, 194),
(194, 195),
(194, 204),
(195, 196),
(196, 197),
(197, 198),
(198, 199),
(200, 201),
(201, 202),
(202, 203),
(204, 205),
(205, 206),
(206, 207),
(206, 211),
(207, 208),
(208, 209),
(209, 210),
(211, 212),
(212, 213),
(213, 214),
(214, 215),
(215, 216),
(216, 218),
(216, 268),
(217, 268),
(218, 219),
(219, 220),
(220, 221),
(221, 222),
(222, 223),
(223, 224),
(224, 225),
(225, 226),
(226, 227),
(226, 234),
(227, 228),
(228, 229),
(228, 233),
(229, 230),
(230, 231),
(231, 232),
(233, 244),
(234, 235),
(235, 236),
(236, 238),
(237, 238),
(238, 239),
(239, 240),
(240, 241),
(241, 242),
(242, 243),
(244, 245),
(245, 246),
(247, 248),
(248, 249),
(249, 250),
(250, 251),
(251, 252),
(251, 261),
(252, 253),
(253, 254),
(254, 255),
(255, 256),
(256, 257),
(257, 258),
(258, 259),
(259, 260),
(261, 262),
(262, 263),
(263, 264),
(264, 265),
(265, 266),
(266, 269),
(269, 270),
(270, 271),
(271, 272),
(272, 273),
(273, 274),
(274, 275),
(275, 276),
(276, 277),
(277, 278),
(278, 279),
(279, 280),
(280, 281),
(281, 282),
(282, 283),
(283, 284),
(284, 285),
(285, 286),
(285, 296),
(285, 304),
(287, 288),
(287, 340),
(288, 289),
(289, 290),
(289, 297),
(290, 291),
(291, 292),
(292, 293),
(293, 294),
(294, 295),
(295, 296),
(297, 298),
(298, 299),
(299, 300),
(300, 301),
(301, 302),
(304, 305),
(305, 306),
(306, 307),
(307, 308),
(308, 309),
(309, 310),
(310, 311),
(311, 312),
(312, 313),
(312, 324),
(313, 314),
(314, 315),
(315, 316),
(316, 317),
(317, 318),
(318, 319),
(319, 320),
(320, 321),
(321, 322),
(322, 323),
(324, 325),
(325, 326),
(326, 327),
(327, 328),
(328, 329),
(329, 330),
(330, 331),
(331, 332),
(332, 333),
(332, 335),
(333, 334),
(335, 336),
(336, 337),
(337, 338),
(338, 339),
(340, 341),
(341, 342),
(342, 343),
(343, 344),
(344, 345),
(345, 347),
(347, 348),
(348, 349),
(349, 350),
(350, 351),
(351, 352);

-- --------------------------------------------------------

--
-- Table structure for table `tblcustomers`
--

CREATE TABLE `tblcustomers` (
  `fldmeterno` varchar(20) NOT NULL,
  `fldfullname` varchar(50) DEFAULT NULL,
  `fldlatitude` varchar(20) DEFAULT NULL,
  `fldlongitude` varchar(20) DEFAULT NULL,
  `fldstatus` varchar(15) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcustomers`
--

INSERT INTO `tblcustomers` (`fldmeterno`, `fldfullname`, `fldlatitude`, `fldlongitude`, `fldstatus`, `fldpassword`) VALUES
('0782135087', 'John Moyo', '-17.7630838', '31.0849382', 'Active', '25d55ad283aa400af464c76d713c07ad'),
('1234567890', 'Anesu Ndoro', '0', '0', 'Active', '25d55ad283aa400af464c76d713c07ad');

-- --------------------------------------------------------

--
-- Table structure for table `tblmessages`
--

CREATE TABLE `tblmessages` (
  `fldmessageid` int(11) NOT NULL,
  `fldmeterno` varchar(20) DEFAULT NULL,
  `fldbox` varchar(20) DEFAULT NULL,
  `fldmessage` varchar(200) DEFAULT NULL,
  `fldstatus` varchar(10) DEFAULT NULL,
  `fldtimestamp` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblmessages`
--

INSERT INTO `tblmessages` (`fldmessageid`, `fldmeterno`, `fldbox`, `fldmessage`, `fldstatus`, `fldtimestamp`) VALUES
(1, '0782135087', 'inbox', 'Hie', 'Active', '1536491794000'),
(2, '0782135087', 'outbox', 'hey', 'success', '1536493011000'),
(3, '0782135087', 'outbox', 'I would like to enquire my balance', 'success', '1536493633000'),
(4, '0782135087', 'inbox', 'Ok i will get back to you soon', 'success', '1536577026000'),
(7, '0782135087', 'inbox', 'ok', 'success', '1536742846000');

-- --------------------------------------------------------

--
-- Table structure for table `tblnodes`
--

CREATE TABLE `tblnodes` (
  `fldnodeid` int(11) NOT NULL,
  `fldtype` varchar(20) DEFAULT NULL,
  `fldmaterial` varchar(20) DEFAULT NULL,
  `fldpoles` int(11) DEFAULT NULL,
  `fldbranches` int(11) DEFAULT NULL,
  `fldcomment` varchar(100) DEFAULT NULL,
  `fldlatitude` varchar(20) DEFAULT NULL,
  `fldlongitude` varchar(20) DEFAULT NULL,
  `fldtimestamp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblnodes`
--

INSERT INTO `tblnodes` (`fldnodeid`, `fldtype`, `fldmaterial`, `fldpoles`, `fldbranches`, `fldcomment`, `fldlatitude`, `fldlongitude`, `fldtimestamp`) VALUES
(188, 'Regular', 'Concrete', 1, 2, '', '-19.511170089339824', '29.84111472833115', '1536676120991'),
(189, 'Regular', 'Concrete', 1, 2, '', '-19.511501477713946', '29.8410677573886', '1536676170659'),
(190, 'Regular', 'Concrete', 1, 2, '', '-19.51178463381922', '29.84105702855254', '1536676172746'),
(191, 'Regular', 'Concrete', 1, 2, '', '-19.512098127500227', '29.841014113208303', '1536676173921'),
(192, 'Regular', 'Concrete', 2, 3, '', '-19.512371169888446', '29.841019477626332', '1536676175029'),
(193, 'Regular', 'Concrete', 1, 2, '', '-19.512704887736767', '29.840976562282094', '1536676176124'),
(194, 'Circuit Breaker', 'Concrete', 1, 3, '', '-19.512952647511966', '29.840939011355886', '1536676177702'),
(195, 'Regular', 'Concrete', 1, 2, '', '-19.512917253281618', '29.841260876437673', '1536676179334'),
(196, 'Regular', 'Concrete', 1, 2, '', '-19.51288691536371', '29.84153982617522', '1536676180357'),
(197, 'Regular', 'Concrete', 1, 2, '', '-19.512800957898747', '29.84185632683898', '1536676181257'),
(198, 'Regular', 'Concrete', 1, 2, '', '-19.5127200567135', '29.842183556338796', '1536676182045'),
(199, 'Regular', 'Concrete', 1, 1, '', '-19.51266949345217', '29.842398133059987', '1536676184569'),
(200, 'Regular', 'Concrete', 1, 2, '', '-19.51231049384201', '29.84130379178191', '1536676190092'),
(201, 'Regular', 'Concrete', 1, 2, '', '-19.512234648751974', '29.841657843371877', '1536676191302'),
(202, 'Regular', 'Concrete', 1, 2, '', '-19.51214363459694', '29.842146005412587', '1536676192689'),
(203, 'Regular', 'Concrete', 1, 1, '', '-19.512032395004564', '29.842532243510732', '1536676194173'),
(204, 'Regular', 'Concrete', 1, 2, '', '-19.513235801075876', '29.840939011355886', '1536676199702'),
(205, 'Regular', 'Concrete', 1, 2, '', '-19.51339254658552', '29.840901460429677', '1536676200735'),
(206, 'Regular', 'Concrete', 1, 3, '', '-19.513615023822165', '29.84086390950347', '1536676202496'),
(207, 'Regular', 'Concrete', 1, 2, '', '-19.51365547419594', '29.8406171462741', '1536676211953'),
(208, 'Regular', 'Concrete', 1, 2, '', '-19.51367569937902', '29.84033819653655', '1536676213032'),
(209, 'Regular', 'Concrete', 1, 2, '', '-19.51369086826468', '29.840027060290822', '1536676214441'),
(210, 'Regular', 'Concrete', 1, 1, '', '-19.51369086826468', '29.839737381717214', '1536676218177'),
(211, 'Regular', 'Concrete', 1, 2, '', '-19.51375660008608', '29.84086390950347', '1536676220050'),
(212, 'Regular', 'Concrete', 1, 2, '', '-19.513913345090817', '29.84085854508544', '1536676221719'),
(213, 'Regular', 'Concrete', 1, 2, '', '-19.51414593417261', '29.84082099415923', '1536676222424'),
(214, 'Regular', 'Concrete', 1, 2, '', '-19.514348185276102', '29.84080490090514', '1536676223034'),
(215, 'Regular', 'Concrete', 1, 2, '', '-19.51457571746508', '29.84078880765105', '1536676223735'),
(216, 'Transformer', 'Concrete', 1, 3, 'Chasis No: 34357457435E', '-19.51476785550863', '29.840772714396962', '1536676224402'),
(217, 'Regular', 'Concrete', 1, 1, '', '-19.515452998374524', '29.840058088302612', '1536676231285'),
(218, 'Regular', 'Concrete', 1, 2, '', '-19.51521538055209', '29.840756621142873', '1536676235074'),
(219, 'Regular', 'Concrete', 1, 2, '', '-19.515478305197977', '29.840745892306813', '1536676236456'),
(220, 'Regular', 'Concrete', 1, 2, '', '-19.515812016632722', '29.840745892306813', '1536676237380'),
(221, 'Regular', 'Concrete', 1, 2, '', '-19.516105277627894', '29.840745892306813', '1536676238013'),
(222, 'Regular', 'Concrete', 1, 2, '', '-19.516388425670147', '29.840745892306813', '1536676238604'),
(223, 'Regular', 'Concrete', 1, 2, '', '-19.51674236002552', '29.840713705798635', '1536676239161'),
(224, 'Regular', 'Concrete', 1, 2, '', '-19.51712663073391', '29.840681519290456', '1536676240253'),
(225, 'Regular', 'Concrete', 1, 2, '', '-19.517460338765854', '29.840702976962575', '1536676241155'),
(226, 'Regular', 'Concrete', 1, 3, '', '-19.517763709106184', '29.840692248126516', '1536676242241'),
(227, 'Regular', 'Concrete', 1, 2, '', '-19.51802662960721', '29.840917553683767', '1536676242877'),
(228, 'Regular', 'Concrete', 1, 2, '', '-19.518178314317126', '29.840992655536184', '1536676243747'),
(229, 'Regular', 'Concrete', 1, 2, '', '-19.518562581611796', '29.841271605273732', '1536676244884'),
(230, 'Regular', 'Concrete', 1, 2, '', '-19.5188153885443', '29.84131452061797', '1536676245538'),
(231, 'Regular', 'Concrete', 1, 2, '', '-19.519068195081367', '29.84135743596221', '1536676246379'),
(232, 'Regular', 'Concrete', 1, 1, '', '-19.51928055226692', '29.841389622470388', '1536676247199'),
(233, 'Regular', 'Concrete', 1, 2, '', '-19.51827943737798', '29.840692248126516', '1536676249533'),
(234, 'Regular', 'Concrete', 1, 2, '', '-19.517778310012798', '29.84043855518871', '1536676260402'),
(235, 'Regular', 'Concrete', 1, 2, '', '-19.51783898400705', '29.840205203004416', '1536676261194'),
(236, 'Regular', 'Concrete', 1, 2, '', '-19.517879433323902', '29.840012083955344', '1536676262403'),
(237, 'Regular', 'Concrete', 1, 2, '', '-19.517732804502156', '29.839853833623465', '1536676267251'),
(238, 'Regular', 'Concrete', 1, 3, '', '-19.517952747684895', '29.83986188025051', '1536676267995'),
(239, 'Regular', 'Concrete', 1, 2, '', '-19.518144881714562', '29.839880655713614', '1536676268876'),
(240, 'Regular', 'Concrete', 1, 2, '', '-19.518256117101032', '29.839904795594748', '1536676269869'),
(241, 'Regular', 'Concrete', 1, 2, '', '-19.518395161226476', '29.839928935475882', '1536676270499'),
(242, 'Regular', 'Concrete', 1, 2, '', '-19.518578925702712', '29.839915524430808', '1536676275941'),
(243, 'Regular', 'Concrete', 1, 1, '', '-19.518816564206364', '29.839931617684897', '1536676277005'),
(244, 'Regular', 'Concrete', 1, 2, '', '-19.518695216929007', '29.840462695069846', '1536676284253'),
(245, 'Regular', 'Concrete', 1, 2, '', '-19.518902518472718', '29.84058607668453', '1536676286025'),
(246, 'Regular', 'Concrete', 1, 1, '', '-19.519261503443932', '29.8405807122665', '1536676287148'),
(247, 'Regular', 'Concrete', 1, 1, '', '-19.518653566527473', '29.83758509159088', '1536676292326'),
(248, 'Regular', 'Concrete', 1, 2, '', '-19.51790645740549', '29.837512265153464', '1536676296271'),
(249, 'Regular', 'Concrete', 1, 2, '', '-19.517496907673237', '29.83764637560421', '1536676298054'),
(250, 'Regular', 'Concrete', 1, 2, '', '-19.517183424461027', '29.83781803698116', '1536676299382'),
(251, 'Regular', 'Concrete', 1, 3, '', '-19.51690533400583', '29.837957511849936', '1536676300734'),
(252, 'Regular', 'Concrete', 1, 2, '', '-19.516692973699712', '29.837721477456626', '1536676302012'),
(253, 'Regular', 'Concrete', 1, 2, '', '-19.516637355478196', '29.837474714227255', '1536676302957'),
(254, 'Regular', 'Concrete', 1, 2, '', '-19.516874996836318', '29.83731914610439', '1536676303576'),
(255, 'Regular', 'Concrete', 1, 2, '', '-19.517062075957593', '29.837260137506064', '1536676304154'),
(256, 'Regular', 'Concrete', 1, 2, '', '-19.517466570614754', '29.83708847612911', '1536676305192'),
(257, 'Regular', 'Concrete', 1, 2, '', '-19.517658705222324', '29.836991916604575', '1536676305751'),
(258, 'Regular', 'Concrete', 1, 2, '', '-19.517840727271466', '29.836906085916098', '1536676306289'),
(259, 'Regular', 'Concrete', 1, 2, '', '-19.518042973752312', '29.83682561964565', '1536676306808'),
(260, 'Regular', 'Concrete', 1, 1, '', '-19.51827050074079', '29.836702238030966', '1536676307614'),
(261, 'Regular', 'Concrete', 1, 2, '', '-19.516632299275297', '29.838268648095664', '1536676320342'),
(262, 'Regular', 'Concrete', 1, 2, '', '-19.516409826190905', '29.838429580636557', '1536676321098'),
(263, 'Regular', 'Concrete', 1, 2, '', '-19.51619240901717', '29.838526140161093', '1536676321841'),
(264, 'Regular', 'Concrete', 1, 2, '', '-19.516030610000424', '29.83860124201351', '1536676322455'),
(265, 'Regular', 'Concrete', 1, 2, '', '-19.515808136087966', '29.838713894792136', '1536676323188'),
(266, 'Regular', 'Concrete', 1, 2, '', '-19.51550981831574', '29.83883191198879', '1536676324008'),
(267, 'Regular', 'Concrete', 1, 2, '', '-19.514917036059842', '29.84011173248291', '1536676334921'),
(268, 'Regular', 'Concrete', 1, 2, '', '-19.514917036059842', '29.84011173248291', '1536676337772'),
(269, 'Regular', 'Concrete', 1, 2, '', '-19.51526241609701', '29.838612349790992', '1536676343399'),
(270, 'Regular', 'Concrete', 1, 2, '', '-19.51520679738331', '29.83844068841404', '1536676344585'),
(271, 'Regular', 'Concrete', 1, 2, '', '-19.515151178650466', '29.838247569364967', '1536676345351'),
(272, 'Regular', 'Concrete', 1, 2, '', '-19.515075334893016', '29.837995441717567', '1536676346049'),
(273, 'Regular', 'Concrete', 1, 2, '', '-19.514974209827752', '29.837780864996375', '1536676346779'),
(274, 'Regular', 'Concrete', 1, 2, '', '-19.514645552928748', '29.83790424661106', '1536676349147'),
(275, 'Regular', 'Concrete', 1, 2, '', '-19.51433206418712', '29.837990077299537', '1536676351231'),
(276, 'Transformer', 'Concrete', 1, 2, 'Chasis No: 24357457435X', '-19.513978124554693', '29.837775500578346', '1536676352531'),
(277, 'Regular', 'Concrete', 1, 2, '', '-19.51385677364518', '29.837544830603065', '1536676353360'),
(278, 'Regular', 'Concrete', 1, 2, '', '-19.513588790064052', '29.83715859250492', '1536676356029'),
(279, 'Regular', 'Concrete', 1, 2, '', '-19.513421932138186', '29.837008388800086', '1536676356731'),
(280, 'Regular', 'Concrete', 1, 2, '', '-19.51321967987599', '29.836825998587074', '1536676357461'),
(281, 'Regular', 'Concrete', 1, 2, '', '-19.513027539992528', '29.836552413267555', '1536676358727'),
(282, 'Regular', 'Concrete', 1, 2, '', '-19.51280506194749', '29.8363807518906', '1536676359520'),
(283, 'Regular', 'Concrete', 1, 2, '', '-19.51251179496584', '29.83619836167759', '1536676360289'),
(284, 'Regular', 'Concrete', 1, 2, '', '-19.51236516127553', '29.836048157972755', '1536676361041'),
(285, 'Circuit Breaker', 'Concrete', 2, 4, '', '-19.512405611962002', '29.835833581251563', '1536676361752'),
(286, 'Regular', 'Concrete', 1, 1, '', '-19.51252696396069', '29.835715564054908', '1536676362545'),
(287, 'Regular', 'Concrete', 1, 2, '', '-19.510782520224037', '29.839561851782264', '1536676378745'),
(288, 'Regular', 'Concrete', 1, 2, '', '-19.510807802151735', '29.839003952307166', '1536676379528'),
(289, 'Transformer', 'Concrete', 2, 3, 'Chasis No: 14357457435V', '-19.51093421173085', '29.838537247938575', '1536676380579'),
(290, 'Regular', 'Concrete', 1, 2, '', '-19.511207256084507', '29.83820465402073', '1536676381426'),
(291, 'Regular', 'Concrete', 1, 2, '', '-19.511399398131065', '29.83788815335697', '1536676382173'),
(292, 'Regular', 'Concrete', 1, 2, '', '-19.511505581795678', '29.83763602570957', '1536676383035'),
(293, 'Regular', 'Concrete', 1, 2, '', '-19.511657272624177', '29.83718005017704', '1536676385770'),
(294, 'Regular', 'Concrete', 1, 2, '', '-19.511788737893752', '29.836799176496925', '1536676386602'),
(295, 'Regular', 'Concrete', 1, 2, '', '-19.5118848086001', '29.83644512490696', '1536676387283'),
(296, 'Regular', 'Concrete', 1, 2, '', '-19.512056724458432', '29.836241277021827', '1536676388283'),
(297, 'Regular', 'Concrete', 1, 2, '', '-19.511116241351182', '29.838596256536903', '1536676393884'),
(298, 'Regular', 'Concrete', 1, 2, '', '-19.511313439875302', '29.838612349790992', '1536676394609'),
(299, 'Regular', 'Concrete', 1, 2, '', '-19.511460074519384', '29.838617714209022', '1536676395178'),
(300, 'Regular', 'Concrete', 1, 2, '', '-19.511687610772807', '29.83863917188114', '1536676395938'),
(301, 'Regular', 'Concrete', 1, 2, '', '-19.511980879249354', '29.838714273733558', '1536676396637'),
(302, 'Regular', 'Concrete', 1, 1, '', '-19.512228640133984', '29.838767917913856', '1536676398467'),
(304, 'Regular', 'Concrete', 1, 2, '', '-19.512419438811655', '29.835786332283078', '1536735569204'),
(305, 'Regular', 'Concrete', 1, 2, '', '-19.512409326141853', '29.835544933471738', '1536735570505'),
(306, 'Regular', 'Concrete', 1, 2, '', '-19.512389100800366', '29.83527134815222', '1536735571530'),
(307, 'Regular', 'Concrete', 1, 2, '', '-19.512343593772712', '29.835056771431027', '1536735575267'),
(308, 'Regular', 'Concrete', 1, 2, '', '-19.5122020162715', '29.83475636402136', '1536735576642'),
(309, 'Regular', 'Concrete', 1, 2, '', '-19.51215145284815', '29.83446668544775', '1536735577539'),
(310, 'Regular', 'Concrete', 1, 2, '', '-19.512126171130564', '29.834187735710202', '1536735578337'),
(311, 'Regular', 'Concrete', 1, 2, '', '-19.512045269607686', '29.833839048538266', '1536735579194'),
(312, 'Transformer', 'Concrete', 1, 3, 'Chasis No: 44357457435Q', '-19.51199470613533', '29.833549369964658', '1536735580242'),
(313, 'Regular', 'Concrete', 1, 2, '', '-19.51182784656438', '29.833329428825436', '1536735585761'),
(314, 'Regular', 'Concrete', 1, 2, '', '-19.511610423228703', '29.833179225120602', '1536735586661'),
(315, 'Regular', 'Concrete', 1, 2, '', '-19.51138288686667', '29.833061207923947', '1536735587403'),
(316, 'Regular', 'Concrete', 1, 2, '', '-19.5111300683111', '29.83295928398138', '1536735588342'),
(317, 'Regular', 'Concrete', 1, 2, '', '-19.510836798291432', '29.832825173530637', '1536735589124'),
(318, 'Regular', 'Concrete', 1, 2, '', '-19.510695219470875', '29.832589139137326', '1536735591130'),
(319, 'Regular', 'Concrete', 1, 2, '', '-19.510609260840774', '29.832369197998105', '1536735591795'),
(320, 'Regular', 'Concrete', 1, 2, '', '-19.51052835855895', '29.832149256858884', '1536735592387'),
(321, 'Regular', 'Concrete', 1, 2, '', '-19.51042723064972', '29.831843485031186', '1536735592956'),
(322, 'Regular', 'Concrete', 1, 2, '', '-19.510341271877166', '29.83153234878546', '1536735593554'),
(323, 'Regular', 'Concrete', 1, 2, '', '-19.510230031044863', '29.83128022113806', '1536735594281'),
(324, 'Regular', 'Concrete', 1, 2, '', '-19.512030100567646', '29.83345817485815', '1536735600923'),
(325, 'Regular', 'Concrete', 1, 2, '', '-19.512105945753646', '29.83322750488287', '1536735601579'),
(326, 'Regular', 'Concrete', 1, 2, '', '-19.5121716782194', '29.832868088874875', '1536735602308'),
(327, 'Regular', 'Concrete', 1, 2, '', '-19.512222241636398', '29.832653512153684', '1536735603083'),
(328, 'Regular', 'Concrete', 1, 2, '', '-19.512298086732272', '29.832438935432492', '1536735604636'),
(329, 'Regular', 'Concrete', 1, 2, '', '-19.512378988128656', '29.83227263847357', '1536735606180'),
(330, 'Regular', 'Concrete', 1, 2, '', '-19.512414382476837', '29.832047332916318', '1536735606979'),
(331, 'Regular', 'Concrete', 1, 2, '', '-19.5124801148172', '29.831897129211484', '1536735607974'),
(332, 'Regular', 'Concrete', 1, 3, '', '-19.512535734468948', '29.831618179473935', '1536735609040'),
(333, 'Regular', 'Concrete', 1, 2, '', '-19.512641917387327', '29.831408967170773', '1536735610012'),
(334, 'Regular', 'Concrete', 1, 1, '', '-19.512712705960833', '29.831119288597165', '1536735611037'),
(335, 'Regular', 'Concrete', 1, 2, '', '-19.51260146675997', '29.831671823654233', '1536735614792'),
(336, 'Regular', 'Concrete', 1, 2, '', '-19.512743043911424', '29.83170401016241', '1536735615509'),
(337, 'Regular', 'Concrete', 1, 2, '', '-19.51298069099409', '29.83175228992468', '1536735616291'),
(338, 'Regular', 'Concrete', 1, 2, '', '-19.51310204256116', '29.83178447643286', '1536735617797'),
(339, 'Regular', 'Concrete', 1, 1, '', '-19.513198112487142', '29.831848849449216', '1536735618997'),
(340, 'Regular', 'Concrete', 1, 2, '', '-19.51073684889655', '29.839669351184284', '1536736159894'),
(341, 'Regular', 'Concrete', 1, 2, '', '-19.510697661889754', '29.839841012561237', '1536736161155'),
(342, 'Regular', 'Concrete', 1, 2, '', '-19.510620551945447', '29.84001267393819', '1536736164371'),
(343, 'Regular', 'Concrete', 1, 2, '', '-19.510575048024663', '29.84017630016058', '1536736166778'),
(344, 'Regular', 'Concrete', 1, 2, '', '-19.51053965327385', '29.840394900195292', '1536736168067'),
(345, 'Regular', 'Concrete', 1, 2, '', '-19.510521955895552', '29.840565220467738', '1536736168995'),
(346, 'Regular', 'Concrete', 1, 2, '', '-19.51049920212058', '29.840778456084422', '1536736171433'),
(347, 'Regular', 'Concrete', 1, 2, '', '-19.51048276883667', '29.84090586101263', '1536736172386'),
(348, 'Regular', 'Concrete', 1, 2, '', '-19.51057884031894', '29.840938047520808', '1536736176227'),
(349, 'Regular', 'Concrete', 1, 2, '', '-19.51068755271687', '29.84096352850645', '1536736177283'),
(350, 'Regular', 'Concrete', 1, 2, '', '-19.51082028287106', '29.840980962865046', '1536736178498'),
(351, 'Regular', 'Concrete', 1, 2, '', '-19.510940371964317', '29.840997056119136', '1536736179593'),
(352, 'Regular', 'Concrete', 1, 2, '', '-19.511083214664367', '29.84100510274618', '1536736182791');

-- --------------------------------------------------------

--
-- Table structure for table `tblreports`
--

CREATE TABLE `tblreports` (
  `fldreportid` int(11) NOT NULL,
  `fldmeterno` varchar(20) NOT NULL,
  `fldtype` varchar(20) DEFAULT NULL,
  `fldlatitude` varchar(20) NOT NULL,
  `fldlongitude` varchar(20) NOT NULL,
  `fldstatus` varchar(20) DEFAULT NULL,
  `fldcomment` varchar(100) DEFAULT NULL,
  `fldtimestamp` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblreports`
--

INSERT INTO `tblreports` (`fldreportid`, `fldmeterno`, `fldtype`, `fldlatitude`, `fldlongitude`, `fldstatus`, `fldcomment`, `fldtimestamp`) VALUES
(7, '0782135087', 'Blackout', '-19.49559203296712', '29.837906626832137', 'unattended', '', '1536576857000');

-- --------------------------------------------------------

--
-- Table structure for table `tblservice_logs`
--

CREATE TABLE `tblservice_logs` (
  `fldchasisno` varchar(50) NOT NULL,
  `fldservice_date` varchar(10) NOT NULL,
  `fldservice_type` varchar(20) NOT NULL,
  `fldreport_path` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblservice_logs`
--

INSERT INTO `tblservice_logs` (`fldchasisno`, `fldservice_date`, `fldservice_type`, `fldreport_path`) VALUES
('23243G', '2018-04-14', 'Routine Service', '1523725261_1.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `tblsurveyors`
--

CREATE TABLE `tblsurveyors` (
  `fldphoneno` int(11) NOT NULL,
  `fldfullname` varchar(50) DEFAULT NULL,
  `flddistrict` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsurveyors`
--

INSERT INTO `tblsurveyors` (`fldphoneno`, `fldfullname`, `flddistrict`, `fldpassword`) VALUES
(712923278, 'Peter Ndebele', 'Northern Region', '25d55ad283aa400af464c76d713c07ad'),
(782135087, 'James Moyo', 'Northern Region', '25d55ad283aa400af464c76d713c07ad');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `fldemail` varchar(64) NOT NULL,
  `fldfirstname` varchar(20) DEFAULT NULL,
  `fldlastname` varchar(20) DEFAULT NULL,
  `flddepartment` varchar(50) NOT NULL,
  `fldaccesslevel` varchar(20) DEFAULT NULL,
  `fldpassword` varchar(32) DEFAULT NULL,
  `fldbanned` varchar(3) NOT NULL DEFAULT 'No'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`fldemail`, `fldfirstname`, `fldlastname`, `flddepartment`, `fldaccesslevel`, `fldpassword`, `fldbanned`) VALUES
('admin@zetdc.co.zw', 'Priscilla', 'Gwaze', 'GIS', 'Administrator', '25d55ad283aa400af464c76d713c07ad', 'No');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblassets`
--
ALTER TABLE `tblassets`
  ADD PRIMARY KEY (`fldchasisno`);

--
-- Indexes for table `tblconnections`
--
ALTER TABLE `tblconnections`
  ADD PRIMARY KEY (`fldnode1`,`fldnode2`),
  ADD KEY `fldnode2` (`fldnode2`);

--
-- Indexes for table `tblcustomers`
--
ALTER TABLE `tblcustomers`
  ADD PRIMARY KEY (`fldmeterno`);

--
-- Indexes for table `tblmessages`
--
ALTER TABLE `tblmessages`
  ADD PRIMARY KEY (`fldmessageid`),
  ADD KEY `fldmeterno` (`fldmeterno`);

--
-- Indexes for table `tblnodes`
--
ALTER TABLE `tblnodes`
  ADD PRIMARY KEY (`fldnodeid`);

--
-- Indexes for table `tblreports`
--
ALTER TABLE `tblreports`
  ADD PRIMARY KEY (`fldreportid`),
  ADD KEY `fldmeterno` (`fldmeterno`);

--
-- Indexes for table `tblservice_logs`
--
ALTER TABLE `tblservice_logs`
  ADD PRIMARY KEY (`fldchasisno`,`fldservice_date`,`fldservice_type`);

--
-- Indexes for table `tblsurveyors`
--
ALTER TABLE `tblsurveyors`
  ADD PRIMARY KEY (`fldphoneno`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`fldemail`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblmessages`
--
ALTER TABLE `tblmessages`
  MODIFY `fldmessageid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblnodes`
--
ALTER TABLE `tblnodes`
  MODIFY `fldnodeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=353;

--
-- AUTO_INCREMENT for table `tblreports`
--
ALTER TABLE `tblreports`
  MODIFY `fldreportid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblconnections`
--
ALTER TABLE `tblconnections`
  ADD CONSTRAINT `tblconnections_ibfk_1` FOREIGN KEY (`fldnode1`) REFERENCES `tblnodes` (`fldnodeid`),
  ADD CONSTRAINT `tblconnections_ibfk_2` FOREIGN KEY (`fldnode2`) REFERENCES `tblnodes` (`fldnodeid`);

--
-- Constraints for table `tblmessages`
--
ALTER TABLE `tblmessages`
  ADD CONSTRAINT `tblmessages_ibfk_1` FOREIGN KEY (`fldmeterno`) REFERENCES `tblcustomers` (`fldmeterno`);

--
-- Constraints for table `tblreports`
--
ALTER TABLE `tblreports`
  ADD CONSTRAINT `tblreports_ibfk_1` FOREIGN KEY (`fldmeterno`) REFERENCES `tblcustomers` (`fldmeterno`);

--
-- Constraints for table `tblservice_logs`
--
ALTER TABLE `tblservice_logs`
  ADD CONSTRAINT `tblservice_logs_ibfk_1` FOREIGN KEY (`fldchasisno`) REFERENCES `tblassets` (`fldchasisno`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
