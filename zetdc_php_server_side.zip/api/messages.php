<?php
	include("connection.php");
    if(isset($_GET["meterno"])){
        $messages=array();
        $array=array();
        $meterno=mysqli_real_escape_string($conn,$_GET["meterno"]);
        $statement="SELECT * FROM tblmessages WHERE fldmeterno='$meterno'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        
        while($record=mysqli_fetch_assoc($query)){
            $temp=array();
            $host= gethostname();
            $ip = gethostbyname($host);
            $temp["messageId"]=$record["fldmessageid"];
            $temp["box"]=$record["fldbox"];
            $temp["message"]=$record["fldmessage"];
            $temp["status"]=$record["fldstatus"];
            $temp["timestamp"]=$record["fldtimestamp"];
            $array[]=$temp;
        }
        $messages["array"]=$array;
        echo json_encode($messages);
    }
?>