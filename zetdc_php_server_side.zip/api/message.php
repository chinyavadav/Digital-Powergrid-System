<?php
	include("connection.php");
	if(isset($_GET["meterno"]) && isset($_GET["message"])){
        $meterno=mysqli_real_escape_string($conn,$_GET["meterno"]);       
        $message=mysqli_real_escape_string($conn,$_GET["message"]);
        $timestamp=time()."000";
        $statement="INSERT INTO tblmessages VALUES('','$meterno','outbox','$message','success','$timestamp')";
	    $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	    $response=array("response"=>"success");
	    echo json_encode($response);
	}
		    
?>