<?php
	include("connection.php");
	if(isset($_GET["reportid"])){
		$reportid=mysqli_real_escape_string($conn,$_GET["reportid"]);
		$statement="DELETE FROM tblreports WHERE fldreportid='$reportid'";
		$query=mysqli_query($conn,$statement) or die(error());
		$response=array("response"=>"success");
		echo json_encode($response);
	}
	function error(){
		$reports=array("response"=>"error");
	}
?>