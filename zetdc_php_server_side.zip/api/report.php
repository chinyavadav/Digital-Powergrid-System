<?php
    include("connection.php");
    if($_SERVER["REQUEST_METHOD"]=="POST"){ 
    	$postdata = file_get_contents("php://input");
        if (isset($postdata)) {
        	$request = json_decode($postdata);
        	$meterno = mysqli_real_escape_string($conn,$request->meterno);
        	$type = mysqli_real_escape_string($conn,$request->type);
        	$lng = mysqli_real_escape_string($conn,$request->lng);
        	$lat = mysqli_real_escape_string($conn,$request->lat);
        	$comment = mysqli_real_escape_string($conn,$request->comment);
			$timestamp=time().'000';

			$execute=mysqli_query($conn,"INSERT INTO tblreports VALUES('','$meterno','$type','$lat','$lng','unattended','$comment','$timestamp')") or die(error());
			$response=array("response"=>"success");
		}else{
			$response=array("response"=>"failed");
		}
		echo json_encode($response);
	}

	function error(){
		$response=array("response"=>"failed");
		echo json_encode($response);
	}
?>