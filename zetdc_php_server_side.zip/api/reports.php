<?php
	include("connection.php");
	if(isset($_GET["meterno"])){
		$meterno=mysqli_real_escape_string($conn,$_GET["meterno"]);
		$statement="SELECT * FROM tblreports WHERE fldmeterno='$meterno'";
		$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
		$reports=array();
		while($report=mysqli_fetch_assoc($query)){
			$reports[]=$report;
		}
		echo json_encode($reports);
	}
?>