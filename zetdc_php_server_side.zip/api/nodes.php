<?php
    include("connection.php");
    if($_SERVER["REQUEST_METHOD"]=="POST"){ 
    	$postdata = file_get_contents("php://input");
        if (isset($postdata)) {
        	$request = json_decode($postdata);           
        	$nodes = $request->nodes;
        	$connections = $request->connections;
        	$conns=array();        	
        	foreach ($nodes as $node) {
        		$execute=mysqli_query($conn,"INSERT INTO tblnodes VALUES('','$node->nodeType','$node->poleMaterial','$node->poles','$node->branches','$node->comment','$node->lat','$node->lng','$node->timestamp')") or die(mysqli_error($conn));

        		$query_nodeid=mysqli_query($conn,"SELECT LAST_INSERT_ID() FROM tblnodes") or die(mysqli_error($conn));
                $nodeid=mysqli_fetch_assoc($query_nodeid)["LAST_INSERT_ID()"];
        		$conns[]=array(
        					"nodeid"=>$nodeid,
        					"timestamp"=>$node->timestamp,
        				);
        	}

        	foreach ($connections as $connection) {
        		$values=getID($conn,$connection);
                if($values!=null){
                    $execute=@mysqli_query($conn,"INSERT INTO tblconnections VALUES('$values[0]','$values[1]')");
                }
        	}			
			$response=array("response"=>"success");
		}else{
			$response=array("response"=>"failed");
		}
		echo json_encode($response);
	}

	function getID($conn,$connection){
		$temp=array();

        $lat0=floatval($connection[0]->lat);
        $lng0=floatval($connection[0]->lng);
        $lat1=floatval($connection[1]->lat);
        $lng1=floatval($connection[1]->lng);

        $statement0="SELECT fldnodeid FROM tblnodes WHERE fldlatitude='$lat0' and fldlongitude='$lng0' LIMIT 0,1";
        $query0=mysqli_query($conn,$statement0) or die(mysql_error($conn));
        if(mysqli_num_rows($query0)==1){
            $nodeid0=mysqli_fetch_assoc($query0)["fldnodeid"];
        }else{
            $nodeid0=null;
        }

        $statement1="SELECT fldnodeid FROM tblnodes WHERE fldlatitude='$lat1' and fldlongitude='$lng1' LIMIT 0,1";
        $query1=mysqli_query($conn,$statement1) or die(mysql_error($conn));
        if(mysqli_num_rows($query1)==1){
            $nodeid1=mysqli_fetch_assoc($query1)["fldnodeid"];
        }else{
            $nodeid1=null;
        }

        if($nodeid0==null || $nodeid1==null){
            return false;
        }else{
            if($nodeid0<$nodeid1){
                $temp[0]=$nodeid0;
                $temp[1]=$nodeid1;
                return $temp;
            }else{
                $temp[0]=$nodeid1;
                $temp[1]=$nodeid0;
                return $temp;
            }            
        }
	}
?>