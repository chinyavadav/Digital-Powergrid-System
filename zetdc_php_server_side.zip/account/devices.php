
<?php include("session.php");include("includes/connection.php");?>
<?php
  if(isset($_GET['remove'])){
    $serialno=mysqli_real_escape_string($conn,$_GET['remove']);
    $execute=mysqli_query($conn,"SELECT fldinventoryid FROM tbldevices WHERE fldserialno='$serialno' LIMIT 0,1") or die(mysqli_error($conn));
    $inventoryid=mysqli_fetch_assoc($execute)['fldinventoryid'];
    if(mysqli_num_rows($execute)==1 && $inventoryid!=""){
      $execute0=mysqli_query($conn,"DELETE FROM tbldevices WHERE fldserialno='$serialno'") or die(mysqli_error($conn));
      $execute1=mysqli_query($conn,"UPDATE tblinventory SET fldqty=fldqty-1 WHERE fldinventoryid='$inventoryid'") or die(mysqli_error($conn));
      echo "<script>alert('Device has been successfully removed from stock!');window.location='devices.php';</script>";
    }else{
      header("Location: devices.php");
    }
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>ZETDC (Pvt) Ltd</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="../styles/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
  <link href="../styles/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php include("sidebar.html");include("header.html");?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active"> Devices List</li>
      </ol>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Devices List</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>Serial No</th>
                  <th>Device Name</th>
                  <th>Purchase Price</th>
                  <th>Purchase Date</th>
                  <th>Stocked Period</th>
                  <th>Color</th>
                  <th></th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>Serial No</th>
                  <th>Device Name</th>
                  <th>Purchase Price</th>
                  <th>Purchase Date</th>
                  <th>Stocked Period</th>
                  <th>Color</th>
                  <th></th>
                </tr>
              </tfoot>
              <tbody>
                <?php
                  $query="SELECT * FROM tbldevices JOIN tblinventory ON tbldevices.fldinventoryid=tblinventory.fldinventoryid WHERE fldstatus='Available'";
                  $execute=mysqli_query($conn,$query) or die(mysqli_error($conn));
                  $count=0;
                  $serials=[];
                  while($record=mysqli_fetch_assoc($execute)){
                    echo "<tr>";
                    echo "<td>$record[fldserialno]</a></td>";
                    echo "<td>$record[fldbrand] $record[fldmodel]</td>";
                    echo "<td>$$record[fldpurchaseprice]</td>";
                    $date1=date_create(date('Y-m-d'));
                    $date2= date_create(substr($record['fldpurchasedate'],0,10));
                    $diff=date_diff($date1,$date2);
                    echo "<td>$record[fldpurchasedate]</td>";
                    if($diff->days>=365){
                      echo "<td style='color:red;'><strong>$diff->days days [Exceeded 365 day limit]</strong></td>";
                    }else{
                      $leftDays=365-$diff->days;
                      echo "<td style='color:green;'><strong>$diff->days days [$leftDays days Left]</strong></td>";
                    }                    
                    echo "<td>$record[fldcolor]</td>";
                    echo "<td><button onclick='remove($count)' class='btn btn-danger'><i class='fa fa-close'></i></a></td>";
                    echo "</tr>";
                    $serials[$count]=$record['fldserialno'];
                    $count=$count+1;
                  }
                ?>
                <script>
                  function remove(id){
                    var serials=<?php echo json_encode($serials); ?>;
                    if(confirm("Are you sure you want to remove device from stock!")==true){
                      window.location='?remove='+serials[id];
                    }                    
                  }
                </script>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © Priscilla Gwaze <?php echo date('Y'); ?></small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="logout.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
  </div>
</body>

</html>
