<?php
    include("session.php");include("includes/connection.php");
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $nodeid=$_POST["txtnodeid"];
        $type=$_POST["cbotype"];
        $material=$_POST["cbomaterial"];
        $poles=$_POST['txtpoles'];
        $branches=$_POST['txtbranches'];
        $comment=$_POST['txtcomment'];
        $execute=mysqli_query($conn,"UPDATE tblnodes SET fldtype='$type',fldpoles='$poles',fldbranches='$branches',fldcomment='$comment' WHERE fldnodeid='$nodeid'") or die(mysqli_error($conn));
        echo "<script>alert('Node has been updated successfully!');window.location='node.php?node=".base64_encode($nodeid)."';</script>";
        exit;
    }

    if($_SERVER["REQUEST_METHOD"]=="GET" && isset($_GET['node'])){
      $nodeid=mysqli_real_escape_string($conn,base64_decode($_GET['node']));
      if(isset($_GET['delete'])){
        $statement_nodes="DELETE FROM tblconnections WHERE fldnode1='$nodeid' or fldnode2='#nodeid'";
        $query=mysqli_query($conn,$statement_nodes) or die(mysqli_error($conn));
        $statement_delete="DELETE FROM tblnodes WHERE fldnodeid='$nodeid'";
        $query=mysqli_query($conn,$statement_delete) or die(mysqli_error($conn));
        echo "<script>alert('Node successfully deleted!');window.location='node.php?node=".base64_encode($nodeid)."';</script>";
      }
      $query=mysqli_query($conn,"SELECT * FROM tblnodes WHERE fldnodeid='$nodeid' LIMIT 0,1");
      if(mysqli_num_rows($query)==1){
        $record=mysqli_fetch_assoc($query);
        $type=$record['fldtype'];
        $material=$record['fldmaterial'];
        $poles=$record['fldpoles'];
        $branches=$record['fldbranches'];
        $comment=$record['fldcomment'];
        $lat=$record['fldlatitude'];
        $long=$record['fldlongitude'];
        $timestamp=$record['fldtimestamp'];
      }else{
        header('Location: nodes.php');
      }
    }else{
      header('Location: nodes.php');
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>ZETDC (Pvt) Ltd</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="../styles/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <script src="vendor/jquery/jquery.min.js"></script>
  <?php include("sidebar.html");include("header.html");?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Node</li>
      </ol>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-map-marker"></i> Node Details
          <div class="btn-group pull-right">
            <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
              Actions
              <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" role="menu">
              <li><a class='dropdown-item' id='delete'>Delete Node</a></li>
              <script type="text/javascript">
                $("#delete").click(function() {
                  if(confirm("Are you sure you want to delete!")==true){
                    var delete_path="<?php echo '?node='.base64_encode($nodeid).'&delete'; ?>";
                    window.location=delete_path;
                  }
                });
              </script>
            </ul>
          </div>
        </div>
        <div class="card-body">
          <div class="col-lg-12">
          <form action="" method="post" role="form">
            <div class="row">
              <div class="col form-group">
                <label>Node ID</label>
                <label class="form-control"><?php echo $nodeid; ?></label>
                <input type="hidden" name="txtnodeid" class="form-control" value="<?php echo $nodeid; ?>"/>
              </div>
              <div class="col form-group">
                <label>Latitude, Longitude</label>
                <label class="form-control">
                  <strong><?php echo  "$lat, $long<a href='map.php?node=$nodeid' class='pull-right'><i class='fa fa-map-marker'></i></a>"; ?></strong>                 
                </label>
              </div>
            </div>
            <div class="row">
              <div class="col form-group">
                <label>Type</label>
                <select name="cbotype" class="form-control" id="cbotype">
                  <option id='Regular'>Regular</option>
                  <option id='Transformer'>Transformer</option>
                  <option id='Ciruit Breaker'>Ciruit Breaker</option>
                  <option id='Dead End'>Dead End</option>
                  <option id='Sub-Station'>Sub-Station</option>
                  <option id='Power-Station'>Power-Station</option>
                </select>
              </div>
              <div class="col form-group">
                <label>Material</label>
                <select name="cbomaterial" class="form-control" id="cbotype">
                  <option id='Wooden'>Wooden</option>
                  <option id='Concrete'>Concrete</option>
                  <option id='Steel'>Steel</option>
                  <option id='FRC'>FRC</option>
                  <option id='N/A'>N/A</option>
                </select>
              </div>
              <script>
                $("#<?php echo $type; ?>").attr("selected","selected");
              </script>
            </div>
            <div class="row">
              <div class="col form-group">
                <label>Poles</label>
                <input type="number" min="0" name="txtpoles" class="form-control" required placeholder="Poles/Node" value="<?php echo $poles; ?>"/>
              </div>
              <div class="col form-group">
                <label>Branches</label>
                <input type="number" min="0" name="txtbranches" class="form-control" required placeholder="Branches on Node" value="<?php echo $branches; ?>"/>
              </div>
            </div>
            <div class="row">
              <div class="col form-group">
                <label>Comment</label>
                <textarea name="txtcomment" class="form-control" maxlength="100"><?php echo $comment; ?></textarea>
              </div>
            </div>
            <div class="row form-group">
              <button id="buton" class="btn btn-success btn-block"><i class="fa fa-save"></i> Update Node</button>
            </div>
          </form>
          </div>
        </div>
      </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright &copy; Priscilla Gwaze <?php echo date('Y'); ?></small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="logout.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
  </div>
</body>

</html>
