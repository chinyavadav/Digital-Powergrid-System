<?php include("session.php");include("includes/connection.php"); ?>
<?php
  if(isset($_GET["reportid"]) && isset($_GET["status"])){
    $reportid=mysqli_real_escape_string($conn,$_GET["reportid"]);
    $status=mysqli_real_escape_string($conn,$_GET["status"]);
    if($status=="unattended"){
      $statement="UPDATE tblreports SET fldstatus='attended' WHERE fldreportid='$reportid'";
    }else if($status=="attended"){
       $statement="UPDATE tblreports SET fldstatus='unattended' WHERE fldreportid='$reportid'";
    }
    $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
    echo "<script>alert('Status successfully changed!');window.location='faults.php';</script>";
        exit;    
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>ZETDC (Pvt) Ltd</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="../styles/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php include("sidebar.html");include("header.html");?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Reported Faults</li>
      </ol>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Reported Faults
          <div class="btn-group pull-right">
            <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
              Actions
              <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" role="menu">
              <li><a class='dropdown-item' href='faults.php'>All Reports</a></li>
              <li><a class='dropdown-item' href='faults.php?unattended'>Unattended Reports</a></li>
            </ul>
          </div>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>Report ID</th>
                  <th>Fault Type</th>
                  <th>Status</th>
                  <th>Date/Time</th>
                  <th>Comment</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>Report ID</th>
                  <th>Fault Type</th>
                  <th>Status</th>
                  <th>Date/Time</th>
                  <th>Comment</th>
                </tr>
              </tfoot>
              <tbody>
                <?php
                  $today=time()-(3600*24);
                  if(isset($_GET['unattended'])){
                    $query="SELECT * FROM tblreports WHERE fldstatus='unattended'"; 
                  }else{
                    $query="SELECT * FROM tblreports"; 
                  }
                  $execute=mysqli_query($conn,$query) or die(mysqli_error($conn));
                  while($record=mysqli_fetch_assoc($execute)){
                    $minutes=(time()-($record['fldtimestamp']/1000))/100;
                    if($minutes>1440){
                      $time="<p class='text-danger'>".(int)($minutes/1440)." Days ago</p>";
                    }elseif($minutes>60){
                      $time="<p class='text-warning'>".(int)($minutes/60)." Hours ago</p>";
                    }elseif($minutes>1){
                      $time="<p class='text-primary'>".(int)$minutes." Minutes ago ";
                    }else{
                      $time="<p class='text-success'>Just Now</p>";
                    }
                    echo "<tr>";
                    echo "<td>$record[fldreportid]</td>";
                    echo "<td>$record[fldtype]</td>";
                    if($record['fldstatus']=='unattended'){
                      echo "<td><a href='faults.php?reportid=$record[fldreportid]&status=unattended' class='btn btn-outline btn-block btn-warning'>Unattended</a></td>";
                    }else{
                      echo "<td><a href='faults.php?reportid=$record[fldreportid]&status=attended' class='btn btn-outline btn-block btn-success'>Attended</a></td>";
                    }                    
                    echo "<td>".date('Y-m-d H:i:s',$record['fldtimestamp']/1000)."</td>";
                    echo "<td>$record[fldcomment] $time</td>";
                    echo "</tr>";
                  }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © Priscilla Gwaze <?php echo date('Y'); ?></small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="logout.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
  </div>
</body>

</html>
