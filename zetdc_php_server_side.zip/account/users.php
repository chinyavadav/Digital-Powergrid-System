<?php include("session.php"); include("includes/connection.php");?>
<?php
  if(isset($_GET['delete'])){
    $email=mysqli_real_escape_string($conn,$_GET['delete']);
    $execute0=mysqli_query($conn,"DELETE FROM tblusers WHERE fldemail='$email'") or die(mysqli_error($conn));
    echo "<script>alert('User has been deleted successfully!');window.location='users.php';</script>";
  }
  if(isset($_GET['ban'])){
    $email=mysqli_real_escape_string($conn,$_GET['ban']);
    if(isset($_GET['true'])){
      $execute0=mysqli_query($conn,"UPDATE tblusers SET fldbanned='Yes' WHERE fldemail='$email'") or die(mysqli_error($conn));
      echo "<script>alert('User has been banned!');window.location='users.php';</script>";
    }else{
      $execute0=mysqli_query($conn,"UPDATE tblusers SET fldbanned='No' WHERE fldemail='$email'") or die(mysqli_error($conn));
      echo "<script>alert('User has been enabled!');window.location='users.php';</script>";
    }
    
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>ZETDC (Pvt) Ltd</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="../styles/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <?php include("sidebar.html");include("header.html");?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active"> Users List</li>
      </ol>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Users List</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>Email</th>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Department</th>
                  <th>Role</th>
                  <th></th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>Email</th>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Department</th>
                  <th>Role</th>
                  <th></th>
                  <th>Delete</th>
                </tr>
              </tfoot>
              <tbody>
                <?php
                  $query="SELECT * FROM tblusers";
                  $execute=mysqli_query($conn,$query) or die(mysqli_error($conn));
                  while($record=mysqli_fetch_assoc($execute)){
                    echo "<tr>";
                    echo "<td><a href='user.php?uid=".base64_encode($record["fldemail"])."'>$record[fldemail]</a></td>";
                    echo "<td>$record[fldfirstname]</td>";
                    echo "<td>$record[fldlastname]</td>";
                    echo "<td>$record[flddepartment]</td>";
                    echo "<td>$record[fldaccesslevel]</td>";
                    if($record['fldbanned']=="No"){
                      echo "<td><a href='?ban=$record[fldemail]&true' class='btn btn-block btn-warning'><i class='fa fa-ban'></i> Disable</a></td>";
                    }else{
                      echo "<td><a href='?ban=$record[fldemail]&false' class='btn btn-block btn-success'><i class='fa fa-check'> Enable</i></a></td>";
                    } 
                    if($accessLevel=="Administrator"){
                      echo "<td><a href='?delete=$record[fldemail]' class='btn btn-danger btn-block'><i class='fa fa-close'></i></a></td>";
                    }else{
                      echo "<td><a class='disabled btn btn-danger btn-block'><i class='fa fa-close'></i></a></td>";
                    }              
                    echo "</tr>";
                  }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © Priscilla Gwaze <?php echo date('Y'); ?></small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="logout.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
  </div>
</body>

</html>
