<?php
    include("session.php");include("includes/connection.php");
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $chasisno=mysqli_real_escape_string($conn,$_POST['txtchasisno']);
        $type=mysqli_real_escape_string($conn,$_POST['cbotype']);
        $status=mysqli_real_escape_string($conn,$_POST['cbostatus']);
        $installationdate=mysqli_real_escape_string($conn,$_POST['dtdecommissioneddate']);
        $specifications=mysqli_real_escape_string($conn,$_POST['txtspecifications']);
        $servicingroutine=mysqli_real_escape_string($conn,$_POST['txtservicingperiod']);
        $decommisioned_date=mysqli_real_escape_string($conn,$_POST['dtdecommissioneddate']);

        $execute=mysqli_query($conn,"UPDATE tblassets SET fldtype='$type', fldstatus='$status',fldinstallationdate='$installationdate',fldspecifications='$specifications', fldservicing_routine_period='$servicingroutine',flddecommissioned_date='$decommisioned_date' WHERE fldchasisno='$chasisno'") or die(mysqli_error($conn));
        echo "<script>alert('Asset has been successfully updated!');window.location='asset.php?chasis=".base64_encode($chasisno)."';</script>";
        exit;
    }

    if($_SERVER["REQUEST_METHOD"]=="GET" && isset($_GET['chasis'])){
      $chasisno=mysqli_real_escape_string($conn,base64_decode($_GET['chasis']));
      if(isset($_GET['delete'])){
        $delete=mysqli_query($conn,"DELETE FROM tblassets WHERE fldchasisno='$chasisno'") or delete($chasisno);//delete
      }
      $query=mysqli_query($conn,"SELECT * FROM tblassets WHERE fldchasisno='$chasisno' LIMIT 0,1");
      if(mysqli_num_rows($query)==1){
        $record=mysqli_fetch_assoc($query);
        $type=$record['fldtype'];
        $status=$record['fldstatus'];
        $installationdate=$record['fldinstallationdate'];
        $specifications=$record['fldspecifications'];
        $servicing_routine_period=$record['fldservicing_routine_period'];
        $decommissioned_date=$record['flddecommissioned_date'];
      }else{
        header('Location: assets.php');
      }
    }else{
      header('Location: assets.php');
    }
    function delete($chasisno){
      echo "<script>alert('Asset cannot be deleted since it is attached to some records in the database!');window.location='asset.php?chasis=".base64_encode($chasisno)."';</script>";
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>ZETDC (Pvt) Ltd</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="../styles/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <script src="vendor/jquery/jquery.min.js"></script>
  <?php include("sidebar.html");include("header.html");?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Asset</li>
      </ol>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-stack-overflow"></i> Asset Details
          <div class="btn-group pull-right">
            <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
              Actions
              <span class="caret"></span>
            </button>
            <ul class="dropdown-menu" role="menu">
              <li><a class='dropdown-item' id='delete'>Delete Asset</a></li>
              <script type="text/javascript">
                $("#delete").click(function() {
                  if(confirm("Are you sure you want to delete the asset and all associated datasets?")==true){
                    var delete_path="<?php echo '?chasis='.base64_encode($chasisno).'&delete'; ?>";
                    window.location=delete_path;
                  }
                });
              </script>
            </ul>
          </div>
        </div>
        <div class="card-body">
          <div class="col-lg-12">
          <form action="" method="post" role="form">
            <div class="row">
              <div class="col form-group">
                <label>Chasis No</label>
                <label class="form-control"><?php echo $chasisno; ?></label>
                <input type="hidden" name="txtchasisno" class="form-control" value="<?php echo $chasisno; ?>"/>
              </div>
              <div class="col form-group">
                <label>Type</label>
                <select name="cbotype" class="form-control" id="cbotype">                  
                  <option id='Transformer'>Transformer</option>
                  <option id='Normal'>Normal</option>
                </select>
              </div>
            </div>
            <div class="row">
              <div class="col form-group">
                <label>Status</label>
                <select name="cbostatus" class="form-control" id="cbotype">            
                  <option id='Unused'>Unused</option>
                  <option id='Operational'>Operational</option>
                  <option id='Faulted'>Faulted</option>
                  <option id='Decommisioned'>Decommisioned</option>                
                </select>
              </div>
              <script>
                $("#<?php echo $type; ?>").attr("selected","selected");
                $("#<?php echo $status; ?>").attr("selected","selected");
              </script>
              <div class="col form-group">
                <label>Installation Date</label>
                <input type="date" name="dtinstallationdate" class="form-control" value="<?php echo $installationdate; ?>"/>
              </div>
            </div>
            <div class="row">
              <div class="col form-group">
                <label>Specifications</label>
                <textarea required name="txtspecifications" class="form-control" placeholder="Asset specifications"><?php echo $specifications; ?></textarea>
                </textarea>
              </div>
            </div>
            <div class="row">
              <div class="col form-group">
                <label>Service Routine Period</label>
                <input type="number" min="0" required placeholder="Servicing Routine Period" class="form-control" name="txtservicingperiod" value="<?php echo $servicing_routine_period; ?>"/>
              </div>
              <div class="col form-group">
                <label>Decommissioned Date</label>
                <input type="date" name="dtdecommissioneddate" class="form-control" value="<?php echo $decommissioned_date; ?>"/>
              </div>
            </div>
            <div class="row form-group">
              <button id="buton" class="btn btn-success btn-block"><i class="fa fa-save"></i> Update Asset</button>
            </div>
          </form>
          </div>
        </div>
      </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright &copy; Priscilla Gwaze <?php echo date('Y'); ?></small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="logout.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
  </div>
</body>

</html>
