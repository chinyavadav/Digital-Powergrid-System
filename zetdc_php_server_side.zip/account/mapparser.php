<?php
	include("includes/connection.php");
	if($_SERVER["REQUEST_METHOD"]=="POST"){
		$tempNode1=$_POST["node1"];
		$tempNode2=$_POST["node2"];
		$command=$_POST["command"];
		if($tempNode1<$tempNode2){
			$node1=$tempNode1;
			$node2=$tempNode2;
		}else{
			$node1=$tempNode2;
			$node2=$tempNode1;
		}
		if($command=="delete"){
			$statement="DELETE FROM tblconnections WHERE fldnode1='$node1' and fldnode2='$node2'";
		}else{
			$statement="INSERT INTO tblconnections VALUES ('$node1','$node2')";
		}
		$execute=mysqli_query($conn,$statement) or die(error());
		$response=array("response"=>"success");
		echo json_encode($response);
	}

	function error(){
		$response=array("response"=>"susccess");
		echo json_encode($response);
	}
?>