<?php
    include("session.php");
    include("includes/connection.php");

    $statement_nodes="SELECT * FROM tblnodes";
    $query_nodes=mysqli_query($conn,$statement_nodes) or die(mysqli_error($conn));
    $nodes=[];
    $connections=[];
    $buffers=[];

    if(isset($_GET["lat"]) && isset($_GET["lng"])){
        $lat= $_GET["lat"];
        $lng= $_GET["lng"];
        $zoom=25;
    }else{
        $lat= "-19.49559203296712";
        $lng= "29.837906626832137";
        $zoom=12;
    }
    if(mysqli_num_rows($query_nodes)!=0){
        while($record=mysqli_fetch_assoc($query_nodes)){
            $nodes[]=$record;
        }

        $statement_buffers="SELECT * FROM tblreports WHERE fldstatus='unattended'";
        $query_buffers=mysqli_query($conn,$statement_buffers) or die(mysqli_error($conn));
        if(mysqli_num_rows($query_buffers)!=0){
             while($record=mysqli_fetch_assoc($query_buffers)){
                $buffers[]=$record;
             }
        }
        $statement_connections="SELECT * FROM tblconnections";
         $query_connections=mysqli_query($conn,$statement_connections) or die(mysqli_error($conn));
        if(mysqli_num_rows($query_connections)!=0){
            $connection=array();
            while($record=mysqli_fetch_assoc($query_connections)){
                $statement_node1="SELECT * FROM tblnodes WHERE fldnodeid='$record[fldnode1]' LIMIT 0,1";
                $query_node1=mysqli_query($conn,$statement_node1) or die(mysqli_error($conn));
                if(mysqli_num_rows($query_node1)==1){
                    $node1=mysqli_fetch_assoc($query_node1);
                }else{
                    $node1=null;
                }
                $statement_node2="SELECT * FROM tblnodes WHERE fldnodeid='$record[fldnode2]' limit 0,1";
                $query_node2=mysqli_query($conn,$statement_node2) or die(mysqli_error($conn));
                if(mysqli_num_rows($query_node2)==1){
                    $node2=mysqli_fetch_assoc($query_node2);
                }else{
                    $node2=null;
                }
                if($node1!=null || $node2!=null){
                    $temp1=array(
                        "lat"=>$node1['fldlatitude'],
                        "lng"=>$node1['fldlongitude']
                    );
                    $temp2=array(
                        "lat"=>$node2['fldlatitude'],
                        "lng"=>$node2['fldlongitude']
                    );
                    $connection=array($temp1,$temp2);
                    $connections[]=$connection;
                }
            }
        }
    }
?>
<!DOCTYPE html>
<html>
      <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>ZETDC (Pvt) Ltd</title>
      <!-- Bootstrap core CSS-->
      <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <!-- Custom fonts for this template-->
      <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
      <link href="../styles/img/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
      <!-- Page level plugin CSS-->
      <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
      <!-- Custom styles for this template-->
      <link href="css/sb-admin.css" rel="stylesheet">
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>
  </head>
  <body>
    <?php include("temp.html"); ?>
    <div id="map"></div>
    <script>
        var map;
        var first=null;
        var last=null;
        var nodes=<?php echo json_encode($nodes); ?>;
        var connections=<?php echo json_encode($connections); ?>;
        var buffers=<?php echo json_encode($buffers); ?>;
        polylines=[];
        var markers=[];

        function initMap() {
            var lat=localStorage.getItem("lat");
            var lng=localStorage.getItem("lng");
            if(lat==null || lng==null){
                lat= <?php echo $lat; ?>;
                lng= <?php echo $lng; ?>;
            }
            var zoom=localStorage.getItem("zoom");
            if(zoom==null){
                zoom=<?php echo $zoom; ?>;
            }
            map = new google.maps.Map(document.getElementById('map'), {
              center: {lat: parseFloat(lat),lng:parseFloat(lng)},
              zoom: parseInt(zoom)
            });
            setMarkers(map);
            setPolylines(map);
            setBuffers(map);
        }

        function setMarkers(map){
            for (var i = 0; i < nodes.length; i++) {
                addMarker(map,nodes[i]);
            }
        }

        function setBuffers(map){
            for (var i = 0; i < buffers.length; i++) {
                addBuffer(map,buffers[i]);
            }
        }

        function addBuffer(map,buffer) {
            var buffer = new google.maps.Circle({
                strokeColor: '#FF0000',
                strokeOpacity: 0.8,
                strokeWeight: 2,
                fillColor: '#7F0000',
                fillOpacity: 0.35,
                map: map,
                center: {lat: parseFloat(buffer.fldlatitude), lng: parseFloat(buffer.fldlongitude)},
                radius: 1000,
                title:JSON.stringify(buffer)
            });
        } 

        function addMarker(map,node) {
            var infowindow = new google.maps.InfoWindow({
                content: '<div id="content"><div id="siteNotice"></div><h1 id="firstHeading" class="firstHeading">'+node.fldtype+' ['+node.fldnodeid+']</h1><div id="bodyContent">Pole Material: '+node.fldmaterial+'\n '+node.fldpoles+' Poles & '+node.fldbranches+' Branches<p>'+node.fldcomment+'</p></div></div>'
            });
            var marker = new google.maps.Marker({
              position: {lat: parseFloat(node.fldlatitude), lng: parseFloat(node.fldlongitude)},
              icon: getIcon(node.fldtype),
              map: map,
              title: node.fldtype,
              data:node
            });
            marker.addListener('dblclick', ()=>{
                first=last;
                last=marker.data;
                if(first!=null && last!=null && last.fldnodeid!=first.fldnodeid){
                    let connection=[
                            {lat: first.fldlatitude, lng: first.fldlongitude},
                            {lat: last.fldlatitude, lng: last.fldlongitude}
                        ];
                    let inverse=[connection[1],connection[0]];
                    if(JSON.stringify(connections).indexOf(JSON.stringify(connection))!=-1 || JSON.stringify(connections).indexOf(JSON.stringify(inverse))!=-1){
                        var choice=confirm('Do you want to disconnect nodes?');
                        if(choice){
                            var temp=[first.fldnodeid,last.fldnodeid];
                            editConnection(temp,"delete");
                        }
                    }else{
                        var choice=confirm('Do you want to connect nodes?');
                        if(choice){
                            var temp=[first.fldnodeid,last.fldnodeid];
                            editConnection(temp,"add");
                        }
                    }
                    first=null;
                    last=null;
                }
            });

            marker.addListener('click', function() {
                infowindow.open(this.map, marker);
                setTimeout(function(){infowindow.close();},'5000');    
            });
            markers.push(marker);
        }

        function getIcon(type){
            switch(type){
                case "Regular":
                    //iconURL='icons/powerlinepole.png';
                    icon= {
                        path: google.maps.SymbolPath.CIRCLE,
                        fillColor: '#525256',
                        fillOpacity: 0.6,
                        strokeColor: '#00A',
                        strokeOpacity: 0.9,
                        strokeWeight: 1,
                        scale: 3
                    };
                    break;
                case "Transformer":
                    icon= {
                        path: google.maps.SymbolPath.CIRCLE,
                        fillColor: '#f90707',
                        fillOpacity: 0.6,
                        strokeColor: '#00A',
                        strokeOpacity: 0.9,
                        strokeWeight: 1,
                        scale: 7
                    };
                    //iconURL="https://chart.googleapis.com/chart?chst=d_map_pin_letter&chld=T|265bb2|000000";
                    break;
                case "Ciruit Breaker":
                    //iconURL='icons/splice.png';
                    icon= {
                        path: google.maps.SymbolPath.CIRCLE,
                        fillColor: '#07f92f',
                        fillOpacity: 0.6,
                        strokeColor: '#00A',
                        strokeOpacity: 0.9,
                        strokeWeight: 1,
                        scale: 7
                    };
                    break;
                case "Sub-Station":
                    //iconURL="icons/powersubstation.png";
                    icon= {
                        path: google.maps.SymbolPath.CIRCLE,
                        fillColor: '#c807f9',
                        fillOpacity: 0.6,
                        strokeColor: '#00A',
                        strokeOpacity: 0.9,
                        strokeWeight: 1,
                        scale: 7
                    };
                    break;
                case "Power-Station":
                    //iconURL="icons/powerplant.png";
                    icon= {
                        path: google.maps.SymbolPath.CIRCLE,
                        fillColor: '#0747f9',
                        fillOpacity: 0.6,
                        strokeColor: '#00A',
                        strokeOpacity: 0.9,
                        strokeWeight: 1,
                        scale: 7
                    };
                    break;
                default:
                    //iconURL='icons/powerlinepole.png';
                    icon= {
                        path: google.maps.SymbolPath.CIRCLE,
                        fillColor: '#525256',
                        fillOpacity: 0.6,
                        strokeColor: '#00A',
                        strokeOpacity: 0.9,
                        strokeWeight: 1,
                        scale: 7
                    };
                    break;
            }
            return icon;
        }
    
        function clearPolylines(){       
            for(var i=0;i<this.polylines.length;i++){
                this.polylines[i].setMap(null);
            }       
        }

        function deletePolylines(){
            this.clearPolylines();
            this.polylines=[];
        }

        function editConnection(connection,command){
            var center=map.getCenter();
            localStorage.lat=center.lat();
            localStorage.lng=center.lng();
            localStorage.zoom=map.getZoom();
            var postData;
            if(command=="delete"){
                postData={
                    "command":"delete",
                    "node1":connection[0],
                    "node2":connection[1]
                };
            }else{
                postData={
                    "command":"add",
                    "node1":connection[0],
                    "node2":connection[1]
                };
            }
            $.post("mapparser.php",postData,function(data){
                    var response=JSON.parse(data);
                    if(command=="delete"){
                        alert("Nodes successfully disconected!");
                    }else{
                        alert("Nodes successfully connected!");
                    }
                    //window.location.reload();
                }
            );
        }

        function addPolyline(map,connection){
            let path=[{lat:parseFloat(connection[0].lat),lng:parseFloat(connection[0].lng)},{lat:parseFloat(connection[1].lat),lng:parseFloat(connection[1].lng)}];
            let line = new google.maps.Polyline({
                path: path,
                map: map,
                strokeColor: '#000000',
                strokeOpacity: 1.0,
                strokeWeight: 1
            });
            polylines.push(line);
        }

        function setPolylines(map){
            clearPolylines();
            for(var i=0;i<connections.length;i++){
                addPolyline(map,connections[i]);
            }
        }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD3Cqt-U1lg2Iw-tGC98eaS1asohQYADSM&callback=initMap"
    async defer></script>
    <script src="vendor/jquery/jquery.min.js"></script>
  </body>
</html>